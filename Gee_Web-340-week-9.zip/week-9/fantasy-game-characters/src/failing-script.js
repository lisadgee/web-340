// This script causes a failure condition when retrieving the data
throw new Error("Failed to fetch data");