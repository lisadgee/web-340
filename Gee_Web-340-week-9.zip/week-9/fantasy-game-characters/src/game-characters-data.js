//Stores the character data and logs the contents
const gameCharacters = [{Class:"Warrior", Gender:"Male", Fact:"I like pie"},
  {Class:"Mage", Gender:"Male", Fact:"I'm scared of monsters"},
  {Class:"Rogue", Gender:"Female", Fact:"I'm allergic to gluten"}
  ];
  
  console.log(JSON.stringify(gameCharacters));